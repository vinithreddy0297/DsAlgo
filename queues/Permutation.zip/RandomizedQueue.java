/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */


import edu.princeton.cs.algs4.StdRandom;

import java.util.Arrays;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class RandomizedQueue<Item> implements Iterable<Item> {
    private Item[] RQ;
    private int high = 0;

    public RandomizedQueue() {
        RQ = (Item []) new Object[1];
    }

    private void resize(int n) {
        Item[] newArray = Arrays.copyOfRange(RQ, 0, n);
        RQ = newArray;
    }

    public boolean isEmpty() {
        return RQ == null || high == 0;
    }

    public void enqueue(Item item) {
        if (item != null) {
            if (high == RQ.length) {
                resize(RQ.length * 2);
            }

            RQ[high++] = item;
        }
        else {
            throw new IllegalArgumentException();
        }
    }

    public Item dequeue() {
        if (isEmpty()) {
            throw new NoSuchElementException();
        }
        if (high < (RQ.length / 4)) {
            resize((RQ.length)/2);
        }
        int randomIndex = 0;
        if (high > 1) {
            randomIndex = (int) (Math.random() * high);
            Item returnval = RQ[randomIndex];
            RQ[randomIndex] = RQ[--high];
            return returnval;
        }
        else {
            high = 0;
            return RQ[1];
        }
    }

    public int size() {
        return high;
    }

    public Item sample() {
        if (isEmpty()) {
            throw new NoSuchElementException();
        }
        int randomIndex = 0;
        if (high > 1) {
            randomIndex = (int) (Math.random() * high);
        }
        return RQ[randomIndex];
    }

    private class RQItertable implements Iterator<Item> {
        private Item[] RQIter;
        private int low = 0;

        public RQItertable() {
            RQIter = RQ;
            StdRandom.shuffle(RQIter);
        }

        public boolean hasNext() {
            return low != high;
        }

        public Item next() {
            if(low == high)
            {
                throw new NoSuchElementException();
            }
            return RQIter[low++];
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }
    }

    public Iterator<Item> iterator() {
        return new RQItertable();
    }

    public static void main(String[] args) {
        RandomizedQueue<Integer> test = new RandomizedQueue<>();

        // adding 10 elements
        for (int i = 0; i < 10; i++) {
            test.enqueue(i);
        }

        for (int i = 0; i < 10; i++) {
            System.out.println(test.dequeue());
        }
    }
}
